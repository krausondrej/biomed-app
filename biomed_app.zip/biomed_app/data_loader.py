# data_loader.py
import os
import pandas as pd

# Base directory and Excel file path
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
EXCEL_FILE = os.path.join(BASE_DIR, 'ExportedData.xlsx')

# Load all data once from Excel
_df_all = pd.read_excel(EXCEL_FILE, parse_dates=['Date of Operation'])
# Extract year for filtering/statistics
_df_all['Year'] = _df_all['Date of Operation'].dt.year


def load_preop_data():
    """
    Načte a přejmenuje sloupce pro Preoperative stránku,
    spočítá skóre bolesti, omezení aktivit a estetického diskomfortu.
    """
    df = _df_all.copy()
    # Rename Excel columns to interní názvy
    df = df.rename(columns={
        'Gender of the patient': 'Gender',
        'Age of patient at day of operation': 'Age',
        'BMI': 'BMI',
        'Please specify the patient\'s comorbidities::No Comorbidities': 'No_Comorbidities',
        'Please specify the patient\'s comorbidities::Diabetes mellitus': 'Diabetes',
        'Please specify the patient\'s comorbidities::COPD': 'COPD',
        'Please specify the patient\'s comorbidities::Hepatic disease': 'Hepatic_Disease',
        'Please specify the patient\'s comorbidities::Renal disease': 'Renal_Disease',
        'Please specify the patient\'s comorbidities::Abdominal aortic aneurysm': 'Aortic_Aneurysm',
        'Please specify the patient\'s comorbidities::Smoker': 'Smoker',
        'Pain at the site of the hernia \nIn rest (laying down)': 'Pain_rest',
        'Pain at the site of the hernia \nDuring activities (walking, biking, sports)': 'Pain_activity',
        'Pain at the site of the hernia \nPain felt during the last week': 'Pain_last_week',
        'Restrictions of activities \nDaily activities (inside the house)': 'Restrict_inside',
        'Restrictions of activities \nOutside the house (walking, biking; driving)': 'Restrict_outside',
        'Restrictions of activities \nDuring sports': 'Restrict_sports',
        'Restrictions of activities \nDuring heavy labour': 'Restrict_heavy',
        'Esthetical discomfort \nThe shape of your abdomen': 'Esthetic_abdomen',
        'Esthetical discomfort \nThe hernia itself': 'Esthetic_hernia',
    })
    # Spočítat skóre
    df['Preop_Pain_Score'] = df[['Pain_rest', 'Pain_activity', 'Pain_last_week']].sum(axis=1)
    df['Preop_Restrict_Score'] = df[['Restrict_inside', 'Restrict_outside', 'Restrict_sports', 'Restrict_heavy']].sum(axis=1)
    df['Esthetic_Discomfort_Score'] = df[['Esthetic_abdomen', 'Esthetic_hernia']].sum(axis=1)
    # Převod komorbidit na 0/1
    for col in ['No_Comorbidities', 'Diabetes', 'COPD', 'Hepatic_Disease', 'Renal_Disease', 'Aortic_Aneurysm', 'Smoker']:
        df[col] = df[col].fillna(0).astype(int)
    return df


def load_oper_data():
    """
    Načte a přejmenuje sloupce pro Operative stránku (GHR, PHR, PVHR, IVHR).
    """
    df = _df_all.copy()
    df = df.rename(columns={
        # Typ operace
        'Incisional Ventral Hernia Repair': 'Operation_Type',
        # Indikace
        'Indication for the surgery?': 'Indication',
        # GHR - strany
        'Side of the groin hernia? Bilateral?::Right': 'GHR_Side_Right',
        'Side of the groin hernia? Bilateral?::Left': 'GHR_Side_Left',
        # GHR - předchozí opravy
        'Number of previous repairs - right side': 'GHR_Prev_Repairs_Right',
        'Number of previous repairs - left side': 'GHR_Prev_Repairs_Left',
        # GHR - typ kýly (pravá)
        'Type of the groin hernia - right side::Lateral (indirect)': 'GHR_Type_Right_Lateral',
        'Type of the groin hernia - right side::Medial (direct)': 'GHR_Type_Right_Medial',
        'Type of the groin hernia - right side::Femoral': 'GHR_Type_Right_Femoral',
        'Type of the groin hernia - right side::Obturator': 'GHR_Type_Right_Obturator',
        # GHR - typ kýly (levá)
        'Type of the groin hernia - left side::Lateral (indirect)': 'GHR_Type_Left_Lateral',
        'Type of the groin hernia - left side::Medial (direct)': 'GHR_Type_Left_Medial',
        'Type of the groin hernia - left side::Femoral': 'GHR_Type_Left_Femoral',
        'Type of the groin hernia - left side::Obturator': 'GHR_Type_Left_Obturator',
        # PHR
        'Type of stoma': 'PHR_Stoma_Type',
        'Number of previous parastomal hernia repairs': 'PHR_Prev_Repairs',
        # PVHR
        'Please specify type of primary ventral hernia': 'PVHR_Subtype',
        # IVHR
        'Number of previous hernia repairs': 'IVHR_Prev_Repairs',
    })
    return df


def load_discharge_data():
    """
    Načte a přejmenuje sloupce pro Discharge stránku.
    """
    df = _df_all.copy()
    df = df.rename(columns={
        'Where there intrahospital  complications ?': 'Intra_Complications',
        'Please enter the type of intrahospital complications::Bleeding complications': 'Comp_Bleeding',
        'Please enter the type of intrahospital complications::Surgical site infection (SSI)': 'Comp_SSI',
        'Please enter the type of intrahospital complications::Mesh infection': 'Comp_Mesh_Infection',
        'Please enter the type of intrahospital complications::Hematoma': 'Comp_Hematoma',
        'Please enter the type of intrahospital complications::Prolonged ileus or obstruction': 'Comp_Prolonged_Ileus',
        'Please enter the type of intrahospital complications::Urinary retention': 'Comp_Urinary_Retention',
        'Please enter the type of intrahospital complications::General complications': 'Comp_General',
    })
    # Boolean převod
    for col in ['Comp_Bleeding', 'Comp_SSI', 'Comp_Mesh_Infection', 'Comp_Hematoma', 'Comp_Prolonged_Ileus', 'Comp_Urinary_Retention', 'Comp_General']:
        df[col] = df[col].fillna(0).astype(int)
    return df


def load_followup_data():
    """
    Načte a přejmenuje sloupce pro Follow Up stránku.
    """
    df = _df_all.copy()
    df = df.rename(columns={
        'Where there  complications at Follow Up ?': 'Followup_Complications',
        'Please enter the type of complications at Follow Up::Seroma': 'FU_Seroma',
        'Please enter the type of complications at Follow Up::Hematoma': 'FU_Hematoma',
        'Please enter the type of complications at Follow Up::Pain': 'FU_Pain',
        'Please enter the type of complications at Follow Up::Surgical site infection (SSI)': 'FU_SSI',
        'Please enter the type of complications at Follow Up::Mesh infection': 'FU_Mesh_Infection',
        'Please enter the type of complications at Follow Up::Other': 'FU_Other',
    })
    for col in ['FU_Seroma', 'FU_Hematoma', 'FU_Pain', 'FU_SSI', 'FU_Mesh_Infection', 'FU_Other']:
        df[col] = df[col].fillna(0).astype(int)
    return df

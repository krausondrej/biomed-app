# styles.py
PRIMARY_COLOR   = "black"
SECONDARY_COLOR = "black"
ACCENT_COLOR    = "black"
